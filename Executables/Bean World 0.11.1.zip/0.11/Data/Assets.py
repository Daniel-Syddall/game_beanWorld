from Data.Const import pygame
from Data.Vars import color,asset

color = {

    "white" : (255,255,255),
    "grey" : (127,127,127),
    "black" : (0,0,0)
    
}