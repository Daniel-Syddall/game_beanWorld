from Data.Const import *

def Temp():
    pass

#
#   - = To create a new Game Func, follow the steps below: = -
#
#
#       1a. Go to ./Game/Main/Func
#
#       1b. Copy this File and paste it into ./Game/Main/Func
#
#       1c. Select an appropriate name for this new Game State
#
#       1d. Within the coppied file, replace any instance of "Temp" with the Name of the new Game state
#                                     (THIS IS INCLUDES THE FILE NAME)
#
#
#       2a. Go to ./Imports/SubData.py
#
#       2b. Copy Line 10 and Paste it on the next avalible line
#
#       2c. On the new coppied lines, replace any instance of the word "Temp" with the Name of the new Game State
#