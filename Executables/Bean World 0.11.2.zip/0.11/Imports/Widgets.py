# Data Import used for Widgets (Used in Blits) #

from Game.Widgets.Button import Widget_Button
from Game.Widgets.Label import Widget_Label