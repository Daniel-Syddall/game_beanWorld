from Game.Main.Func.RPG.Room.Generate.test0 import *
from Game.Main.Func.RPG.Room.Generate.test1 import *
from Game.Main.Func.RPG.Room.Generate.test2 import *

def Room(self):
    self.room = {}
    test0(self)
    test1(self)
    test2(self)